﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoublyLinkedListWithErrors
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the doubly linked list with errors");
            return; // return
        }
    }
}
